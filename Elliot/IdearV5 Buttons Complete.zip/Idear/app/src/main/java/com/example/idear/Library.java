package com.example.idear;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.util.Log;

public class Library extends AppCompatActivity {

    private Button home;
    private Button setting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);

        home = (Button) findViewById(R.id.HomeBTN);
        setting = (Button) findViewById(R.id.SettingsBTN);

        home.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent load= new Intent( Library.this, MainActivity.class);
                startActivity(load);
            }
        });

        setting.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent load= new Intent( Library.this, SettingsAct.class);
                startActivity(load);
            }
        });




    }


}