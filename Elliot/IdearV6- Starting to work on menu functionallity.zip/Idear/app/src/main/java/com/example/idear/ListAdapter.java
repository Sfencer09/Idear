package com.example.idear;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListAdapter extends ArrayAdapter<Image>{
    private static final String TAG = "ArrayAdapter";
    private List<Image> ImageCellList new ArrayList<Image>();

    static class ViewHolders{
        ImageView ImageFilePath;
        TextView Date;
        TextView WordLength;
    }

    public ArrayAddapter (Context context, int textViewID){
        super(context, textViewID);
    }

    @Override
    public void add (Image object){
        ImageCallList.add.(object);
    }

    @Override
    public int getCount(){
        return this.ImageCellList.size();
    }

    @Override
    public View getView(int position, View ViewConvert, ViewGroup parent){
        View row = ViewConvert;
        ImageViewHold viewHold;
        if (row = null){
            LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.listview_row_layout, parent, false);
            viewHold = new ImageView();
            viewHold.Image = (ImageView) row.findViewById(R.id.Image);
            viewHold.Date = (TextView) row.findViewById(R.id.Date);
            viewHold.WordLength = (TextView) row.findViewById(R.id.WordLength);
            row.setTag(viewHold);
        }
        else{

        }
    }
}


