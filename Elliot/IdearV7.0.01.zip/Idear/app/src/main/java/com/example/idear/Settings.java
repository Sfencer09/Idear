package com.example.idear;

import android.util.Log;

public class Settings {
    private static Settings instance = new Settings();

    private double speed;
    private int voiceOption;

    private Settings() {
        speed = 1;
        voiceOption = 0;
    }

    public static Settings getInstance() {
        return instance;
    }

    public double getSpeed() {
        return speed;
    }

    public int voiceOption() {
        return voiceOption;
    }

    public void setSpeed(double sp) {
        Log.i("Settings", "Speed: " + speed);
        speed = sp;
    }

    public void setVoiceOption(int opt) {
        Log.i("Settings", "Opt: " + opt);
        Log.i("Settings", "VoiceOption: " + voiceOption);
        if (opt >= 0 && opt < 3) {
            voiceOption = opt;
        }
    }
}
/*

   // https://stackoverflow.com/questions/9815245/android-text-to-speech-male-voice
   //  https://developer.android.com/reference/android/speech/tts/Voice.html#getFeatures()

}
*/