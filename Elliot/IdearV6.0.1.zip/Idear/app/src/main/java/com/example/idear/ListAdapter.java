package com.example.idear;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListAdapter extends ArrayAdapter<Photo>{
    private static final String TAG = "ArrayAdapter";
    private List<Photo> PhotoCellList new ArrayList<Photo>();

    static class ViewHolder{
        ImageView photoView;
        TextView dateView;
        TextView wordLengthView;
    }

    public ArrayAdapter (Context context, int textViewID){
        super(context, textViewID);
    }

    @Override
    public void add (Photo object){
        ImageCallList.add(object);
    }

    @Override
    public int getCount(){
        return this.ImageCellList.size();
    }

    @Override
    public View getView(int position, View ViewConvert, ViewGroup parent){
        View row = ViewConvert;
        ViewHolder viewHold;
        if (row == null){
            LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.listview_row_layout, parent, false);
            viewHold = new ViewHolder();
            viewHold.photoView = (ImageView) row.findViewById(R.id.Image);
            viewHold.dateView = (TextView) row.findViewById(R.id.Date);
            viewHold.wordLengthView = (TextView) row.findViewById(R.id.WordLength);
            row.setTag(viewHold);
        }
        else{
            viewHold = (ViewHolder) row.getTag();
        }
        getCount count = getItem(position);
        viewHold.Image.setImageResource(Image.getImageFilePath());
        viewHold.Date.setText(Image.getDate());
        viewHold.WordLength = setText(Image.getWordLength);
        return row;

    }

    public Bitmap decodeToBitmap(byte[] decodeByte){
        return BitmapFactory.decodeByteArray(decodedByte, 0, decodedByte.length);
    }

}


