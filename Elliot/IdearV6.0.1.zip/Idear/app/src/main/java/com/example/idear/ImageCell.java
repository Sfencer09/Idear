package com.example.idear;

public class ImageCell{
    private string ImageFilePath;
    private string Date;
    private int WordLength;

    public ImageCell(string path, string d, int wL){
        ImageFilePath= path;
        Date = d;
        WordLength= wL;
    }

    public string getImageFilePath() {
        return ImageFilePath;
    }

    public string getDate() {
        return Date;
    }

    public int getWordLength() {
        return WordLength;
    }
}
