package com.example.idear;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.speech.tts.TextToSpeech;
import android.widget.Toast;
import android.util.Log;
import java.util.Locale;
import android.speech.tts.Voice;

public class Settings {
    private static Settings instance = new Settings();

    private double speed;
    private int voiceOption;
    //private TextToSpeech textToSpeech;

    private Settings() {
        speed = 1;
        voiceOption = 0;
        //init_tts();
    }

 /*
    public void init_tts(){
        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int ttsLang = textToSpeech.setLanguage(Locale.US);

                    if (ttsLang == TextToSpeech.LANG_MISSING_DATA
                            || ttsLang == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "The Language is not supported!");
                    } else {
                        Log.i("TTS", "Language Supported.");
                    }
                    Log.i("TTS", "Initialization success.");
                } else {
                    // Toast.makeText(getApplicationContext(), "TTS Initialization failed!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


  */

    //public TextToSpeech getTextToSpeech() {
    //    return textToSpeech;
  //  }
    public static Settings getInstance() {
        return instance;
    }
    public double getSpeed() {
        return speed;
    }
    public int voiceOption() {
        return voiceOption;
    }
    public void setSpeed(double sp) {
        Log.i("Settings", "Speed: " + speed);
        speed = sp;
       // textToSpeech.setSpeechRate((float)speed);


    }
/*
    public void setVoiceOption(int opt) {
        Log.i("Settings", "Opt: " + opt);
        Log.i("Settings", "VoiceOption: " + voiceOption);
        if (opt >= 0 && opt < 3) {
            voiceOption = opt;
        }
        Voice v = null;
        if (voiceOption == 0) {
             v = new Voice("en-us-x-sfg#male_1-local", new Locale("en", "US"), 400, 200, true, null);
        } else if (voiceOption == 1) {
             v = new Voice("en-us-x-sfg#female_1-local", new Locale("en", "US"), 400, 200, true, null);
        } else if (voiceOption == 2) { //English- Great Britain
             v = new Voice("en-gb-x-gbd-local", new Locale("en", "gb"), 400, 200, true, null);
        }
        textToSpeech.setVoice(v);
    }
    */

}

   // https://stackoverflow.com/questions/9815245/android-text-to-speech-male-voice
   // https://developer.android.com/reference/android/speech/tts/Voice.html#getFeatures()


// a. we need to find a way to instantiate TextToSpeech without using getApplicationContext()
    //https://stackoverflow.com/questions/12805491/android-tts-from-multiple-activities
//OR
//b. instantiate the Settings TextToSpeech object as null in the Settings constructor, then create a new TextToSpeech object on every Activity that we wish to use it on.