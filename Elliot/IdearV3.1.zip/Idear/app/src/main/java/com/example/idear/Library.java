package com.example.idear;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Library extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);
    }
}